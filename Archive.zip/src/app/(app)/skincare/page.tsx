import { SkincareRitualClient } from "@/components/skincare/skincare-ritual-client";

export default function SkincarePage() {
  return <SkincareRitualClient />;
}
