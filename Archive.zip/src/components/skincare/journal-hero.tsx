interface Props {
  title: string;
  focus: string;
  completion: number;
}

export function JournalHero({ title, focus, completion }: Props) {
  return (
    <section className="relative overflow-hidden rounded-[2rem] border border-white/8 bg-[#13151f] p-6 backdrop-blur-xl md:p-8">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(59,130,246,0.15),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(99,102,241,0.10),transparent_28%)]" />
      <div className="absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] [background-size:28px_28px]" />

      <div className="relative space-y-8">
        <div className="space-y-2">
          <p className="font-[var(--font-inter)] text-xs font-semibold uppercase tracking-[0.24em] text-white/30">
            Skin Journal
          </p>
          <h1 className="font-[var(--font-plus-jakarta-sans)] text-4xl font-semibold tracking-tight text-[#FFFFE4] md:text-5xl">
            {title}
          </h1>
        </div>

        <div className="rounded-[1.75rem] border border-white/8 bg-black/15 p-5 md:p-6">
          <p className="font-[var(--font-inter)] text-[11px] font-semibold uppercase tracking-[0.2em] text-white/30">
            Current Status
          </p>
          <div className="mt-3 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div className="space-y-2">
              <h2 className="font-[var(--font-plus-jakarta-sans)] text-3xl font-semibold text-[#FFFFE4]">
                {focus}
              </h2>
              <div className="flex items-end gap-3">
                <span className="font-[var(--font-plus-jakarta-sans)] text-5xl font-semibold leading-none text-[#FFFFE4]">
                  {completion}%
                </span>
                <span className="pb-1 font-[var(--font-inter)] text-sm text-white/45">
                  Ritual Completion
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 h-2.5 overflow-hidden rounded-full bg-white/8">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 via-blue-400 to-indigo-400"
              style={{ width: `${completion}%` }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
