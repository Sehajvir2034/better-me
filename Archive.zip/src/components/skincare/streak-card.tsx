import { Flame, Sparkles } from "lucide-react";

interface Props {
  streak: number;
}

export function StreakCard({ streak }: Props) {
  return (
    <section className="relative overflow-hidden rounded-[2rem] border border-orange-500/20 bg-orange-500 p-6 text-slate-950 shadow-[0_24px_80px_rgba(249,115,22,0.24)]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.25),transparent_32%)]" />
      <div className="relative flex h-full flex-col justify-between gap-8">
        <div className="space-y-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/10">
            <Flame className="h-5 w-5" />
          </div>

          <div className="space-y-2">
            <h2 className="font-[var(--font-plus-jakarta-sans)] text-4xl font-semibold tracking-tight">
              {streak} Day Streak
            </h2>
            <p className="max-w-xs font-[var(--font-inter)] text-sm leading-6 text-black/65">
              Your skin is looking radiant. Keep the momentum and stay
              consistent with tonight&apos;s ritual.
            </p>
          </div>
        </div>

        <button className="inline-flex w-fit items-center gap-2 rounded-full bg-black/80 px-5 py-3 font-[var(--font-inter)] text-sm font-semibold text-orange-100 transition hover:bg-black">
          <Sparkles className="h-4 w-4" />
          View History
        </button>
      </div>
    </section>
  );
}
