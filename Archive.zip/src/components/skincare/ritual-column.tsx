"use client";

import { Clock3, Droplets, MoonStar } from "lucide-react";
import { RitualStepCard } from "./ritual-step-card";
import type { RitualStep } from "./ritual-types";

interface Props {
  title: string;
  subtitle: string;
  badge: string;
  type: "morning" | "evening";
  steps: RitualStep[];
  onToggle: (id: number) => void;
}

export function RitualColumn({
  title,
  subtitle,
  badge,
  type,
  steps,
  onToggle,
}: Props) {
  const Icon = type === "morning" ? Droplets : MoonStar;

  return (
    <section className="rounded-[2rem] border border-white/8 bg-[#0b1120]/70 p-5 backdrop-blur-xl md:p-6">
      <div className="mb-5 flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full border border-blue-500/20 bg-blue-500/10 text-blue-400">
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-[var(--font-plus-jakarta-sans)] text-2xl font-semibold tracking-tight text-[#FFFFE4]">
              {title}
            </h2>
            <p className="mt-1 font-[var(--font-inter)] text-sm text-white/45">
              {subtitle}
            </p>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 rounded-full border border-white/8 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
          <Clock3 className="h-3.5 w-3.5" />
          {badge}
        </div>
      </div>

      <div className="space-y-3">
        {steps.map((step) => (
          <RitualStepCard key={step.id} step={step} onToggle={onToggle} />
        ))}
      </div>
    </section>
  );
}
