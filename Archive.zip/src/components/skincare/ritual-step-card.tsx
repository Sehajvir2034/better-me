"use client";

import { Check, Circle, Play } from "lucide-react";
import type { RitualStep, RitualStatus } from "./ritual-types";

interface Props {
  step: RitualStep;
  onToggle: (id: number) => void;
}

const statusStyles: Record<RitualStatus, string> = {
  todo: "border-white/8 bg-[#0d1220]/80",
  progress:
    "border-blue-500/30 bg-blue-500/8 shadow-[0_0_0_1px_rgba(59,130,246,0.12)]",
  done: "border-white/10 bg-white/[0.03]",
};

const indicatorStyles: Record<RitualStatus, string> = {
  todo: "border-white/15 text-white/30",
  progress:
    "border-blue-400/40 bg-blue-500 text-white shadow-[0_0_24px_rgba(59,130,246,0.35)]",
  done: "border-green-400/20 bg-[#c7d2fe] text-slate-950",
};

function StatusIcon({ status }: { status: RitualStatus }) {
  if (status === "done") return <Check className="h-4 w-4" />;
  if (status === "progress")
    return <Play className="h-3.5 w-3.5 fill-current" />;
  return <Circle className="h-4 w-4" />;
}

export function RitualStepCard({ step, onToggle }: Props) {
  return (
    <button
      onClick={() => onToggle(step.id)}
      className={`group w-full rounded-[1.75rem] border p-5 text-left backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-white/14 ${statusStyles[step.status]}`}
    >
      <div className="flex items-start gap-4">
        <div
          className={`mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-all ${indicatorStyles[step.status]}`}
        >
          <StatusIcon status={step.status} />
        </div>

        <div className="min-w-0 flex-1 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/35">
              <span>{step.step}</span>
              <span>•</span>
              <span>{step.duration}</span>
              <span>•</span>
              <span>{step.product}</span>
            </div>

            <span className="rounded-full border border-white/8 bg-white/[0.03] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
              {step.status === "todo"
                ? "To Do"
                : step.status === "progress"
                  ? "In Progress"
                  : "Done"}
            </span>
          </div>

          <div className="space-y-1.5">
            <h3 className="font-[var(--font-plus-jakarta-sans)] text-lg font-semibold tracking-tight text-[#FFFFE4]">
              {step.title}
            </h3>
            <p className="font-[var(--font-inter)] text-sm leading-6 text-white/58">
              {step.description}
            </p>
          </div>
        </div>
      </div>
    </button>
  );
}
