"use client";

import { useMemo, useState } from "react";
import { JournalHero } from "./journal-hero";
import { StreakCard } from "./streak-card";
import { RitualColumn } from "./ritual-column";
import {
  EnvironmentalLoadCard,
  LogPhotoCard,
  ShelfLifeCard,
} from "./footer-widgets";
import type { RitualStep, RitualStatus } from "./ritual-types";

const initialMorning: RitualStep[] = [
  {
    id: 1,
    step: "Step 01",
    duration: "1 Min",
    product: "CeraVe Hydrating",
    title: "Hydrating Cleanser",
    description:
      "Apply to damp skin and massage in circular motions for 60 seconds to preserve natural oils.",
    status: "todo",
  },
  {
    id: 2,
    step: "Step 02",
    duration: "2 Min",
    product: "SkinCeuticals CE",
    title: "Vitamin C Serum",
    description:
      "Pat 3-4 drops onto face and neck, then wait briefly for full absorption before moisturizer.",
    status: "todo",
  },
  {
    id: 3,
    step: "Step 03",
    duration: "All Day",
    product: "La Roche-Posay",
    title: "Broad Spectrum SPF 50",
    description:
      "Use the two-finger method and apply evenly across face, ears, and neck for complete coverage.",
    status: "todo",
  },
];

const initialEvening: RitualStep[] = [
  {
    id: 4,
    step: "Step 01",
    duration: "3 Min",
    product: "Bioderma Sensibio",
    title: "Double Cleanse",
    description:
      "Oil-based balm followed by water-based cleanser to remove SPF and daily buildup thoroughly.",
    status: "done",
  },
  {
    id: 5,
    step: "Step 02",
    duration: "3 Min",
    product: "Tretinoin 0.05%",
    title: "Retinoid Treatment",
    description:
      "Use a pea-sized amount on dry skin and avoid the eye area to support gradual skin renewal.",
    status: "progress",
  },
  {
    id: 6,
    step: "Step 03",
    duration: "3 Min",
    product: "Barrier Repair",
    title: "Night Recovery Cream",
    description:
      "Seal in treatment with a rich moisturizer focused on ceramides and long-lasting hydration.",
    status: "todo",
  },
];

function nextStatus(status: RitualStatus): RitualStatus {
  if (status === "todo") return "progress";
  if (status === "progress") return "done";
  return "todo";
}

function completionFromSteps(steps: RitualStep[]) {
  const total = steps.length;
  const score = steps.reduce((acc, step) => {
    if (step.status === "done") return acc + 1;
    if (step.status === "progress") return acc + 0.5;
    return acc;
  }, 0);

  return Math.round((score / total) * 100);
}

export function SkincareRitualClient() {
  const [morning, setMorning] = useState(initialMorning);
  const [evening, setEvening] = useState(initialEvening);

  function toggleStep(id: number) {
    setMorning((prev) =>
      prev.map((step) =>
        step.id === id ? { ...step, status: nextStatus(step.status) } : step,
      ),
    );
    setEvening((prev) =>
      prev.map((step) =>
        step.id === id ? { ...step, status: nextStatus(step.status) } : step,
      ),
    );
  }

  const completion = useMemo(
    () => completionFromSteps([...morning, ...evening]),
    [morning, evening],
  );

  return (
    <div className="min-h-screen bg-background px-4 pb-10 pt-6 text-[#FFFFE4] md:px-6 xl:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.5fr)_360px] xl:items-stretch">
          <JournalHero
            title="Skin Vitality Journal"
            focus="Hydration Focus Week"
            completion={completion}
          />
          <StreakCard streak={12} />
        </div>

        <div className="grid gap-6 xl:grid-cols-2">
          <RitualColumn
            title="Morning Ritual"
            subtitle="Focus: Protection & Hydration"
            badge="07:30 AM"
            type="morning"
            steps={morning}
            onToggle={toggleStep}
          />

          <RitualColumn
            title="Evening Ritual"
            subtitle="Focus: Repair & Renewal"
            badge="08:30 PM"
            type="evening"
            steps={evening}
            onToggle={toggleStep}
          />
        </div>

        <div className="grid gap-6 xl:grid-cols-[320px_minmax(0,1fr)_300px]">
          <ShelfLifeCard />
          <EnvironmentalLoadCard />
          <LogPhotoCard />
        </div>
      </div>
    </div>
  );
}
