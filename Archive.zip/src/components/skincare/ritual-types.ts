export type RitualStatus = "todo" | "progress" | "done";

export interface RitualStep {
  id: number;
  step: string;
  duration: string;
  product: string;
  title: string;
  description: string;
  status: RitualStatus;
}
