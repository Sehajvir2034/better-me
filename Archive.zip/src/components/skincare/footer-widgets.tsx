import { Camera, CloudSun, Package2 } from "lucide-react";

export function ShelfLifeCard() {
  return (
    <div className="rounded-[2rem] border border-white/8 bg-[#13151f] p-5 backdrop-blur-xl">
      <div className="mb-5 flex items-center justify-between">
        <h3 className="font-[var(--font-plus-jakarta-sans)] text-lg font-semibold text-[#FFFFE4]">
          Shelf Life
        </h3>
        <Package2 className="h-5 w-5 text-white/30" />
      </div>

      <div className="space-y-4 font-[var(--font-inter)]">
        <div className="flex items-end justify-between gap-3 border-b border-white/8 pb-3">
          <div>
            <p className="text-sm text-white/50">Retinol Serum</p>
            <p className="mt-1 text-xs text-white/28">Opened 4 weeks ago</p>
          </div>
          <p className="text-sm font-semibold text-[#f97316]">12 Days Left</p>
        </div>

        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-sm text-white/50">Night Cream</p>
            <p className="mt-1 text-xs text-white/28">Daily use product</p>
          </div>
          <p className="text-sm font-semibold text-blue-400">48 Days Left</p>
        </div>
      </div>
    </div>
  );
}

export function EnvironmentalLoadCard() {
  return (
    <div className="rounded-[2rem] border border-white/8 bg-[#13151f] p-5 backdrop-blur-xl">
      <div className="mb-5 flex items-center justify-between">
        <h3 className="font-[var(--font-plus-jakarta-sans)] text-lg font-semibold text-[#FFFFE4]">
          Environmental Load
        </h3>
        <CloudSun className="h-5 w-5 text-white/30" />
      </div>

      <div className="grid grid-cols-2 gap-4 font-[var(--font-inter)]">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/28">
            UV Index
          </p>
          <p className="mt-2 text-3xl font-semibold text-[#FFFFE4]">High (7)</p>
          <p className="mt-1 text-sm text-blue-400">Re-apply SPF at 12:00</p>
        </div>

        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/28">
            Humidity
          </p>
          <p className="mt-2 text-3xl font-semibold text-[#FFFFE4]">22%</p>
          <p className="mt-1 text-sm text-orange-400">Extra hydration needed</p>
        </div>
      </div>
    </div>
  );
}

export function LogPhotoCard() {
  return (
    <button className="flex h-full min-h-[220px] flex-col items-center justify-center rounded-[2rem] border border-blue-200/20 bg-[#c7d2fe] p-6 text-center text-slate-950 transition hover:scale-[1.01] hover:bg-[#d7defe]">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/40">
        <Camera className="h-6 w-6" />
      </div>
      <h3 className="mt-5 font-[var(--font-plus-jakarta-sans)] text-2xl font-semibold">
        Log Skin Photo
      </h3>
      <p className="mt-2 max-w-xs font-[var(--font-inter)] text-sm leading-6 text-slate-700">
        Track visual progress over time with a quick ritual snapshot.
      </p>
      <span className="mt-6 rounded-full bg-slate-950 px-5 py-3 font-[var(--font-inter)] text-sm font-semibold text-blue-50">
        Open Camera
      </span>
    </button>
  );
}
